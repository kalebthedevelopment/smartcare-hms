import React, { useState } from 'react';
import { useHMS } from '../../context/HMSContext';
import { Patient, Vitals, PrescriptionItem } from '../../types/hms';
import { StaffManagementModal } from '../common/StaffManagementModal';
import {
  Stethoscope,
  Search,
  FlaskConical,
  Pill,
  Send,
  History,
  CheckCircle2,
  AlertCircle,
  Activity,
  User,
  Plus,
  Trash2,
  Clock,
  Sparkles,
  Key,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { motion } from 'motion/react';

export const DoctorDashboard: React.FC = () => {
  const {
    patients,
    medicalRecords,
    labTests,
    medicineStock,
    createMedicalRecord,
    getPatientByCardNumber,
    currentStaff,
  } = useHMS();

  const [showStaffModal, setShowStaffModal] = useState(false);
  const [modalMode, setModalMode] = useState<'ADD_STAFF' | 'CHANGE_PASSWORD' | 'MANAGE_LIST' | 'SWITCH_STAFF'>('CHANGE_PASSWORD');

  // Active Selected Patient State
  const [searchCardInput, setSearchCardInput] = useState('ETH-00102');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(() => {
    return patients.find((p) => p.cardNumber === 'ETH-00102') || patients[0] || null;
  });

  // Clinical Vitals Form
  const [vitals, setVitals] = useState<Vitals>({
    bp: '130/85',
    temp: 38.8,
    pulse: 94,
    weight: 68,
    spo2: 97,
  });

  const [symptoms, setSymptoms] = useState('High fever for 3 days, chills, joint fatigue, headache and mild nausea.');
  const [diagnosis, setDiagnosis] = useState('Suspected Typhoid / Malaria fever.');
  const [doctorNotes, setDoctorNotes] = useState('Patient presented with acute febrile illness. Ordered Widal & Malaria blood film.');

  // Lab Test Requisition Checklist
  const availableLabTests = [
    { name: 'Widal Serology Test (Typhoid)', category: 'Serology', price: 350 },
    { name: 'Malaria Blood Film (BS for MPS)', category: 'Parasitology', price: 250 },
    { name: 'Complete Blood Count (CBC)', category: 'Hematology', price: 400 },
    { name: 'Fasting Blood Sugar (FBS)', category: 'Biochemistry', price: 180 },
    { name: 'Urinalysis (Routine)', category: 'Microbiology', price: 150 },
    { name: 'Stool Examination', category: 'Parasitology', price: 150 },
  ];

  const [selectedLabs, setSelectedLabs] = useState<string[]>([
    'Widal Serology Test (Typhoid)',
    'Malaria Blood Film (BS for MPS)',
  ]);

  // E-Prescription Items
  const [prescriptions, setPrescriptions] = useState<PrescriptionItem[]>([
    {
      medicineName: 'Ciprofloxacin 500mg',
      dosage: '500mg',
      frequency: 'BID (Twice Daily)',
      duration: '7 Days',
      quantity: 14,
      unitPriceETB: 15,
      totalPriceETB: 210,
    },
  ]);

  const [newMedName, setNewMedName] = useState(medicineStock[0]?.medicineName || 'Amoxicillin 500mg');
  const [newDosage, setNewDosage] = useState('500mg');
  const [newFreq, setNewFreq] = useState('TID');
  const [newDuration, setNewDuration] = useState('5 Days');
  const [newQty, setNewQty] = useState(15);

  const handlePatientSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchCardInput.trim()) return;
    const found = getPatientByCardNumber(searchCardInput);
    if (found) {
      setSelectedPatient(found);
    }
  };

  const handleAddPrescriptionItem = () => {
    const stockItem = medicineStock.find(
      (m) => m.medicineName.toLowerCase() === newMedName.toLowerCase()
    );
    const unitPrice = stockItem ? stockItem.unitPriceETB : 12;
    const totalPrice = unitPrice * newQty;

    const newItem: PrescriptionItem = {
      medicineName: newMedName,
      dosage: newDosage,
      frequency: newFreq,
      duration: newDuration,
      quantity: newQty,
      unitPriceETB: unitPrice,
      totalPriceETB: totalPrice,
    };

    setPrescriptions((prev) => [...prev, newItem]);
  };

  const handleRemovePrescriptionItem = (index: number) => {
    setPrescriptions((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleToggleLab = (testName: string) => {
    setSelectedLabs((prev) =>
      prev.includes(testName)
        ? prev.filter((t) => t !== testName)
        : [...prev, testName]
    );
  };

  const handleSubmitConsultation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;

    const labOrders = selectedLabs.map((name) => {
      const found = availableLabTests.find((t) => t.name === name);
      return {
        testName: name,
        category: found ? found.category : 'General',
        priceETB: found ? found.price : 200,
      };
    });

    createMedicalRecord({
      patientId: selectedPatient.id,
      patientCardNumber: selectedPatient.cardNumber,
      patientName: selectedPatient.fullName,
      doctorId: 'doc-1',
      doctorName: 'Dr. Yonas Tadesse',
      vitals,
      symptoms,
      diagnosis,
      doctorNotes,
      labTestsToOrder: labOrders,
      prescriptionItems: prescriptions,
    });
  };

  // Filter EMR history for selected patient
  const patientHistory = selectedPatient
    ? medicalRecords.filter((m) => m.patientId === selectedPatient.id)
    : [];

  // Live Lab Results for selected patient
  const patientLabResults = selectedPatient
    ? labTests.filter((l) => l.patientId === selectedPatient.id)
    : [];

  const queuePatients = patients.filter(
    (p) => p.status === 'Queued for Doctor' || p.status === 'Lab Completed'
  );

  return (
    <div className="space-y-6">
      {/* Top Doctor Hub Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-2xl shadow-md shrink-0">
            {currentStaff?.avatar || '👨‍⚕️'}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-black text-slate-900 tracking-tight">
                {currentStaff?.fullName || 'Dr. Yonas Tadesse'}
              </h1>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded font-mono">
                {currentStaff?.specialization || 'General Practice'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              EMR Diagnostics Hub • Review patient histories, order lab tests, and write e-prescriptions.
            </p>
          </div>
        </div>

        {/* Patient Queue Switcher & Staff Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              setModalMode('CHANGE_PASSWORD');
              setShowStaffModal(true);
            }}
            className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition"
          >
            <Key className="w-3.5 h-3.5 text-amber-600" />
            <span>Change Password</span>
          </button>

          <form onSubmit={handlePatientSearch} className="flex items-center space-x-2">
            <div className="relative">
              <input
                type="text"
                value={searchCardInput}
                onChange={(e) => setSearchCardInput(e.target.value)}
                placeholder="ETH-00102"
                className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold w-32 focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
            >
              Search
            </button>
          </form>

          <div className="bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl text-xs font-bold text-emerald-800">
            Active Queue: {queuePatients.length}
          </div>
        </div>
      </div>

      {/* Main Grid: Left Patient Banner + EMR History (4 cols), Right Consultation Form (8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Active Patient Overview & EMR History */}
        <div className="lg:col-span-4 space-y-6">
          {/* Active Patient Card */}
          {selectedPatient ? (
            <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-700 relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-700 pb-3 mb-3">
                <span className="text-[10px] uppercase font-mono font-bold text-emerald-400 bg-slate-950 px-2 py-0.5 rounded border border-emerald-800">
                  {selectedPatient.cardNumber}
                </span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {selectedPatient.status}
                </span>
              </div>

              <div className="space-y-1">
                <h3 className="text-xl font-extrabold text-white">{selectedPatient.fullName}</h3>
                <p className="text-xs text-slate-300">
                  {selectedPatient.age} Yrs • {selectedPatient.gender} • Blood: <strong className="text-emerald-400">{selectedPatient.bloodType || 'O+'}</strong>
                </p>
                <p className="text-xs text-slate-400 font-mono">Phone: {selectedPatient.phone}</p>
                <p className="text-[11px] text-slate-400">Emergency: {selectedPatient.emergencyContact}</p>
              </div>
            </div>
          ) : (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
              No patient selected.
            </div>
          )}

          {/* Patient Active Consultation Queue Selector */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider flex items-center justify-between">
              <span>Waiting Patients Queue</span>
              <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded text-[10px] font-mono">
                {queuePatients.length}
              </span>
            </h4>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {queuePatients.map((p) => (
                <div
                  key={p.id}
                  onClick={() => {
                    setSelectedPatient(p);
                    setSearchCardInput(p.cardNumber);
                  }}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition flex items-center justify-between ${
                    selectedPatient?.id === p.id
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <div className="font-bold">{p.fullName}</div>
                    <div className="text-[10px] font-mono text-slate-500">{p.cardNumber}</div>
                  </div>
                  <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded">
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Lab Test Results Feed */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center space-x-2">
              <FlaskConical className="w-4 h-4 text-purple-600" />
              <span>🧪 Lab Results (Real-time Feed)</span>
            </h4>

            {patientLabResults.length === 0 ? (
              <p className="text-xs text-slate-400">No lab requisitions found for this patient.</p>
            ) : (
              <div className="space-y-2">
                {patientLabResults.map((l) => (
                  <div
                    key={l.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-900">
                      <span>{l.testName}</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                          l.status === 'DONE'
                            ? 'bg-emerald-100 text-emerald-800 font-extrabold'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {l.status}
                      </span>
                    </div>

                    {l.results ? (
                      <div className="bg-white p-2 rounded border border-slate-200 font-mono text-[11px] text-slate-800 font-semibold">
                        Result: {l.results}
                      </div>
                    ) : (
                      <div className="text-[11px] text-slate-400 italic">
                        Pending lab technician analysis...
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Doctor Consultation Form & Order Writer */}
        <div className="lg:col-span-8 space-y-6">
          <form onSubmit={handleSubmitConsultation} className="space-y-6">
            {/* Vitals Input Strip */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                <Activity className="w-4 h-4 text-emerald-600" />
                <span>Patient Vital Signs</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    value={vitals.bp}
                    onChange={(e) => setVitals({ ...vitals, bp: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 font-mono text-center font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Temp (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={vitals.temp}
                    onChange={(e) => setVitals({ ...vitals, temp: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 font-mono text-center font-bold text-amber-700"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Pulse (bpm)</label>
                  <input
                    type="number"
                    value={vitals.pulse}
                    onChange={(e) => setVitals({ ...vitals, pulse: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 font-mono text-center font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={vitals.weight}
                    onChange={(e) => setVitals({ ...vitals, weight: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 font-mono text-center font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">SpO2 (%)</label>
                  <input
                    type="number"
                    value={vitals.spo2}
                    onChange={(e) => setVitals({ ...vitals, spo2: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 font-mono text-center font-bold text-emerald-700"
                  />
                </div>
              </div>
            </div>

            {/* Clinical Diagnosis Section */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-bold text-sm text-slate-900">🩺 Clinical Symptoms & Diagnosis</h3>
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Chief Symptoms & Presentation</label>
                  <textarea
                    rows={2}
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Differential Diagnosis</label>
                  <input
                    type="text"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Physician Notes & Directives</label>
                  <textarea
                    rows={2}
                    value={doctorNotes}
                    onChange={(e) => setDoctorNotes(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Order Laboratory Requisitions */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                  <FlaskConical className="w-4 h-4 text-purple-600" />
                  <span>🧪 Order Laboratory Diagnostic Tests</span>
                </h3>
                <span className="text-xs text-purple-700 font-bold bg-purple-50 px-2 py-0.5 rounded">
                  {selectedLabs.length} Selected
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {availableLabTests.map((t) => {
                  const isChecked = selectedLabs.includes(t.name);
                  return (
                    <div
                      key={t.name}
                      onClick={() => handleToggleLab(t.name)}
                      className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                        isChecked
                          ? 'bg-purple-50 border-purple-400 text-purple-900 font-bold'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="rounded text-purple-600 focus:ring-purple-500"
                        />
                        <span>{t.name}</span>
                      </div>
                      <span className="font-mono text-[11px] text-slate-500">ETB {t.price}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* E-Prescription Writer */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                  <Pill className="w-4 h-4 text-emerald-600" />
                  <span>💊 E-Prescription Items</span>
                </h3>
                <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded">
                  Total Billable: ETB {prescriptions.reduce((s, i) => s + i.totalPriceETB, 0)}
                </span>
              </div>

              {/* Added Rx List */}
              <div className="space-y-2">
                {prescriptions.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 text-sm">{item.medicineName}</span>
                      <div className="text-[11px] text-slate-500">
                        Dosage: <strong>{item.dosage}</strong> • Freq: <strong>{item.frequency}</strong> • Duration: {item.duration} (Qty: {item.quantity})
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="font-mono font-bold text-emerald-700">ETB {item.totalPriceETB}</span>
                      <button
                        type="button"
                        onClick={() => handleRemovePrescriptionItem(idx)}
                        className="text-slate-400 hover:text-red-500 transition p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Prescription Row */}
              <div className="p-3 bg-slate-100 border border-slate-300 rounded-xl space-y-3 text-xs">
                <span className="font-bold text-slate-700 block text-[11px] uppercase">
                  Add Medicine From Central Pharmacy Inventory
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Medication Name</label>
                    <select
                      value={newMedName}
                      onChange={(e) => setNewMedName(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-semibold"
                    >
                      {medicineStock.map((m) => (
                        <option key={m.id} value={m.medicineName}>
                          {m.medicineName} (Stock: {m.stockLevel})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Dosage</label>
                    <input
                      type="text"
                      value={newDosage}
                      onChange={(e) => setNewDosage(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Frequency</label>
                    <input
                      type="text"
                      value={newFreq}
                      onChange={(e) => setNewFreq(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-lg p-1.5 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 mb-0.5">Quantity</label>
                    <input
                      type="number"
                      value={newQty}
                      onChange={(e) => setNewQty(Number(e.target.value))}
                      className="w-full bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-mono"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddPrescriptionItem}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs flex items-center space-x-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Drug Item</span>
                </button>
              </div>
            </div>

            {/* Broadcast Consultation Submit */}
            <button
              type="submit"
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-2xl shadow-xl shadow-emerald-900/30 flex items-center justify-center space-x-2 transition text-base"
            >
              <Send className="w-5 h-5" />
              <span>📤 Transmit Requisitions to Lab & Pharmacy Portals</span>
            </button>
          </form>
        </div>
      </div>

      {/* Staff Security Modal */}
      <StaffManagementModal
        isOpen={showStaffModal}
        onClose={() => setShowStaffModal(false)}
        initialMode={modalMode}
      />
    </div>
  );
};
